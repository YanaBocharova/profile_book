﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProfileBook.Enums
{
    public enum SortOption
    {
        NickName,
        Name,
        Date
    }
}
