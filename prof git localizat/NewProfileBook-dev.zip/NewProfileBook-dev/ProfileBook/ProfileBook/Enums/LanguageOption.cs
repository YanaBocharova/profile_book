﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProfileBook.Enums
{
    enum LanguageOption
    {
        en,
        ru
    }
}
